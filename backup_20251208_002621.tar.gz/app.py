from pricing_app.cli import main
if __name__ == "__main__":
    main()